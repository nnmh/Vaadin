package com.example.main_window;

public class company {
    String Name;
    String Type;
    
    int Number;
    public company() {

    }
    public company(String Name, String type,int number) {
        this.Name=Name;
        this.Type=Type;
        this.Number=number;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getType() {
        return Type;
    }

    public void setType(String type) {
        Type = type;
    }

    public int getNumber() {
        return Number;
    }

    public void setNumber(int number) {
        Number = number;
    }
}
