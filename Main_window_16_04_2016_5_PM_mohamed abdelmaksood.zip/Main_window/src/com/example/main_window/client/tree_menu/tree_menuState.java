package com.example.main_window.client.tree_menu;

public class tree_menuState extends com.vaadin.shared.AbstractComponentState {

	// TODO example state
	public String text = "This is tree_menu";

}