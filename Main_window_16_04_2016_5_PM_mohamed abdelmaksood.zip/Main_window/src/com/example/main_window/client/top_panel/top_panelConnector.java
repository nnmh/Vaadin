package com.example.main_window.client.top_panel;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.ui.Widget;

import com.vaadin.client.ui.AbstractComponentConnector;
import com.vaadin.shared.ui.Connect;

import com.example.main_window.top_panel;
import com.example.main_window.client.top_panel.top_panelWidget;
import com.example.main_window.client.top_panel.top_panelServerRpc;
import com.vaadin.client.communication.RpcProxy;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.vaadin.shared.MouseEventDetails;
import com.vaadin.client.MouseEventDetailsBuilder;
import com.example.main_window.client.top_panel.top_panelClientRpc;
import com.example.main_window.client.top_panel.top_panelState;
import com.vaadin.client.communication.StateChangeEvent;

@Connect(top_panel.class)
public class top_panelConnector extends AbstractComponentConnector {

	top_panelServerRpc rpc = RpcProxy
			.create(top_panelServerRpc.class, this);
	
	public top_panelConnector() {
		registerRpc(top_panelClientRpc.class, new top_panelClientRpc() {
			public void alert(String message) {
				// TODO Do something useful
				Window.alert(message);
			}
		});

		// TODO ServerRpc usage example, do something useful instead
		getWidget().addClickHandler(new ClickHandler() {
			public void onClick(ClickEvent event) {
				final MouseEventDetails mouseDetails = MouseEventDetailsBuilder
					.buildMouseEventDetails(event.getNativeEvent(),
								getWidget().getElement());
				rpc.clicked(mouseDetails);
			}
		});

	}

	@Override
	protected Widget createWidget() {
		return GWT.create(top_panelWidget.class);
	}

	@Override
	public top_panelWidget getWidget() {
		return (top_panelWidget) super.getWidget();
	}

	@Override
	public top_panelState getState() {
		return (top_panelState) super.getState();
	}

	@Override
	public void onStateChanged(StateChangeEvent stateChangeEvent) {
		super.onStateChanged(stateChangeEvent);

		// TODO do something useful
		final String text = getState().text;
		getWidget().setText(text);
	}

}

