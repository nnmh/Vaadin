package com.example.main_window.client.top_panel;

public class top_panelState extends com.vaadin.shared.AbstractComponentState {

	// TODO example state
	public String text = "This is top_panel";

}