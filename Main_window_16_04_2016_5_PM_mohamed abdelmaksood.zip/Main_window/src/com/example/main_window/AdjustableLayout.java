package com.example.main_window;

import com.vaadin.server.AbstractErrorMessage.ContentMode;
import com.vaadin.ui.Accordion;
import com.vaadin.ui.CustomLayout;
import com.vaadin.ui.Button;
import com.vaadin.ui.HorizontalSplitPanel;
import com.vaadin.ui.Label;
import com.vaadin.ui.Notification;
import com.vaadin.ui.TabSheet.SelectedTabChangeEvent;
import com.vaadin.ui.TabSheet.SelectedTabChangeListener;
import com.vaadin.ui.Tree;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.Button.ClickEvent;

public class AdjustableLayout extends HorizontalSplitPanel {
    public AdjustableLayout() {
        simple_search search = new simple_search();
        setLocked(true);
        setFirstComponent(createAccordion());
        
        //setSecondComponent(search);
        setSplitPosition(10, Unit.PERCENTAGE);
        setSizeFull();
        }
    private Tree createMenu() {
        Tree menu = new Tree();
        for (int i = 1; i < 6; i++) {
        String item = "item" + i;
        String childItem = "subitem" + i;
        menu.addItem(item);
        menu.addItem(childItem);
        menu.setParent(childItem, item);
        menu.setChildrenAllowed(childItem, false);
        }
        return menu;
        }
    public Accordion createAccordion() {
        Accordion sample = new Accordion();
        simple_search search = new simple_search();
        simple s = new simple();
        detailed d = new detailed();
        search_result r = new search_result();
        register_form re = new register_form();
        sample.setHeight(100.0f, Unit.PERCENTAGE);
        Label b = new Label("new");
        Button c = new Button("Simple");
            final VerticalLayout layout = new VerticalLayout();
            layout.addComponent(b);

            final VerticalLayout layout2 = new VerticalLayout();
            layout2.addComponent(c);

            layout.setMargin(true);
            sample.addTab(layout, "Patient");
            sample.addTab(layout2,"Search");
            sample.addSelectedTabChangeListener(new SelectedTabChangeListener() {
                    public void selectedTabChange(
                    SelectedTabChangeEvent event) {
                    Notification.show("You are watching "
                    + event.getTabSheet().getSelectedTab());
                    }
            });
            c.addClickListener(new Button.ClickListener() {
                public void buttonClick(ClickEvent event) {
                    VerticalLayout v = new VerticalLayout();
                    v.addComponent(search);
                    v.addComponent(r);      

                    setSecondComponent(v);
            }
           });
        
        return sample;
    }
    private  int action(){
        simple_search search = new simple_search();
        
        return 0 ;
    }
}
