package com.example.main_window;

public class Relation {
    String First_Name;
    String Second_Name;
    String Third_Name;
    int Contact;
    String Relation;
    String Payment_Type;

    public Relation() {
    }
    
    public Relation(String fname,String sname,String lname, int contact,String Relation){
            this.First_Name=fname;
            this.Second_Name=sname;
            this.Third_Name=lname;
            this.Contact= contact;
            this.Relation= Relation;
            
            
    }
   

    public String getFirst_Name() {
        return First_Name;
    }

    public void setFirst_Name(String first_Name) {
        First_Name = first_Name;
    }

    public String getSecond_Name() {
        return Second_Name;
    }

    public void setSecond_Name(String second_Name) {
        Second_Name = second_Name;
    }

    public String getThird_Name() {
        return Third_Name;
    }

    public void setThird_Name(String third_Name) {
        Third_Name = third_Name;
    }


    public int getcontact() {
            return this.Contact;
    }

    public void setcontact(int contact) {
            this.Contact = contact;
    }

    public String getCompany() {
            return this.Relation;
    }

    public void setCompany(String Relation) {
            this.Relation = Relation;
    }
    public String getpayment() {
        return this.Payment_Type;
}
    
    public void setpayment(String payment) {
            this.Payment_Type = payment;
    }
    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getType() {
        return Type;
    }

    public void setType(String type) {
        Type = type;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    String Name;
    String Type;
    int number;
}

