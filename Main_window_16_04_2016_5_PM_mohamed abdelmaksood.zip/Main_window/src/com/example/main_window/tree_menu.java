package com.example.main_window;

import com.example.main_window.client.tree_menu.tree_menuClientRpc;
import com.example.main_window.client.tree_menu.tree_menuServerRpc;
import com.vaadin.shared.MouseEventDetails;
import com.vaadin.ui.CustomComponent;
import com.vaadin.ui.Panel;
import com.vaadin.ui.Tree;
import com.example.main_window.client.tree_menu.tree_menuState;

public class tree_menu extends CustomComponent {

	public tree_menu() {
	    Panel p = new Panel();
            p.setSizeUndefined();
            final Object[][] planets = new Object[][]{
                   
                   new Object[]{"Patient","New" , "Registered"},
                   new Object[]{"Search", "Simple", "Detailed"}};
                   

           Tree tree = new Tree("Navigator Menu");

           /* Add planets as root items in the tree. */
           for (int i=0; i<planets.length; i++) {
               String planet = (String) (planets[i][0]);
               tree.addItem(planet);

               if (planets[i].length == 1) {
                   // The planet has no moons so make it a leaf.
                   tree.setChildrenAllowed(planet, false);
               } else {
                   // Add children (moons) under the planets.
                   for (int j=1; j<planets[i].length; j++) {
                       String moon = (String) planets[i][j];

                       // Add the item as a regular item.
                       tree.addItem(moon);

                       // Set it to be a child.
                       tree.setParent(moon, planet);

                       // Make the moons look like leaves.
                       tree.setChildrenAllowed(moon, false);
                   }

                   // Expand the subtree.
                   tree.expandItemsRecursively(planet);
               }
           }
           p.setContent(tree);
            p.setSizeFull();
            this.setSizeUndefined();
            this.setCompositionRoot(p);
	}

	@Override
	public tree_menuState getState() {
		return (tree_menuState) super.getState();
	}
}
