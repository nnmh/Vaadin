package com.example.main_window;


import com.example.main_window.client.top_panel.top_panelClientRpc;
import com.example.main_window.client.top_panel.top_panelServerRpc;
import com.vaadin.shared.MouseEventDetails;
import com.vaadin.ui.CustomComponent;
import com.vaadin.ui.Panel;
import com.example.main_window.client.top_panel.top_panelState;

public class top_panel extends CustomComponent {

	public top_panel() {
	          Panel p = new Panel();
	            p.setSizeUndefined();
	            top top = new top();
	            p.setWidth("100%");
	            p.setContent(top);
	            p.setSizeFull();
	            this.setSizeUndefined();
	            this.setCompositionRoot(p);
	}

}
