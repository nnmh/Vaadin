package com.example.main_window;

import javax.servlet.annotation.WebServlet;

import com.vaadin.annotations.Theme;
import com.vaadin.annotations.VaadinServletConfiguration;
import com.vaadin.server.VaadinRequest;
import com.vaadin.server.VaadinServlet;
import com.vaadin.ui.Button;
import com.vaadin.ui.Button.ClickEvent;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.Label;
import com.vaadin.ui.UI;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.VerticalSplitPanel;

@SuppressWarnings("serial")
@Theme("reindeer")
public class Main_windowUI extends UI {

	@WebServlet(value = "/*", asyncSupported = true)
	@VaadinServletConfiguration(productionMode = false, ui = Main_windowUI.class, widgetset = "com.example.main_window.Main_windowWidgetset")
	public static class Servlet extends VaadinServlet {
	}

	@Override
	protected void init(VaadinRequest request) {
	    VerticalSplitPanel contentPanel = new VerticalSplitPanel();
	    main_panel top = new main_panel();
	    
	    
	    contentPanel.setFirstComponent(top);
	    contentPanel.setSecondComponent(new AdjustableLayout());
	    contentPanel.setSplitPosition(13, Unit.PERCENTAGE);
	    
	    setContent(contentPanel);
	}

}