package com.example.main_window;

import java.util.Map;


import com.vaadin.terminal.PaintException;
import com.vaadin.terminal.PaintTarget;
import com.vaadin.ui.AbstractComponent;
import com.vaadin.ui.CustomComponent;
import com.vaadin.ui.Panel;

/**
 * Server side component for the Vtab_1 widget.
 */
//@com.vaadin.ui.ClientWidget(com.example.main_window.client.ui.Vtab_1.class)
public class tab_1 extends CustomComponent {
            public tab_1() {
                Panel p = new Panel();
                p.setSizeUndefined();
                tab1 top = new tab1();
                p.setContent(top);
                p.setSizeFull();
                this.setSizeUndefined();
                this.setCompositionRoot(p);
            }
}