package com.example.main_window;

import java.util.Map;

import com.vaadin.server.Sizeable.Unit;
import com.vaadin.terminal.PaintException;
import com.vaadin.terminal.PaintTarget;
import com.vaadin.ui.AbstractComponent;
import com.vaadin.ui.CustomComponent;
import com.vaadin.ui.Panel;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.themes.ValoTheme;

/**
 * Server side component for the Vtabs widget.
 */
//@com.vaadin.ui.ClientWidget(com.example.main_window.client.ui.Vtabs.class)
public class tabs extends CustomComponent {

	public tabs() {
	    registeration test = new registeration();
	    Panel p = new Panel();
	    p.setSizeUndefined();
            p.setContent(test);
            p.setSizeFull();
            this.setSizeUndefined();
            this.setCompositionRoot(p);
            test.tabs.setHeight(100.0f, Unit.PERCENTAGE);
            test.tabs.addStyleName(ValoTheme.TABSHEET_FRAMED);
            test.tabs.addStyleName(ValoTheme.TABSHEET_PADDED_TABBAR);
                final VerticalLayout layout1 = new VerticalLayout(new tab_1() );
                layout1.setMargin(true);
                test.tabs.addTab(layout1,"Basics");
                final VerticalLayout layout2 = new VerticalLayout(new tab_2() );
                layout2.setMargin(true);
                test.tabs.addTab(layout2,"Contacts");
                final VerticalLayout layout3 = new VerticalLayout(new RTable() );
                layout3.setMargin(true);
                test.tabs.addTab(layout3,"Relations");
                final VerticalLayout layout4 = new VerticalLayout(new attachdoc() );
                layout4.setMargin(true);
                test.tabs.addTab(layout4,"Attached Documents");
        }

}

