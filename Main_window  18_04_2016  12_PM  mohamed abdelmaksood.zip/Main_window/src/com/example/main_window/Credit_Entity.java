package com.example.main_window;

public class Credit_Entity {
String name;
public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public String getRelation_Type() {
	return relation_Type;
}

public void setRelation_Type(String relation_Type) {
	this.relation_Type = relation_Type;
}

public int getInsurance_Number() {
	return insurance_Number;
}

public void setInsurance_Number(int insurance_Number) {
	this.insurance_Number = insurance_Number;
}

String relation_Type;
int insurance_Number;

	public Credit_Entity(String name2,String Type,int number){
		this.name=name2;
		this.relation_Type=Type;
		this.insurance_Number=number;
	}
	
}
