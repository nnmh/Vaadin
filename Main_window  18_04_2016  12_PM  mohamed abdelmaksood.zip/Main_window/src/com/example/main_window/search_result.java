package com.example.main_window;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;


import com.vaadin.data.util.BeanItemContainer;
import com.vaadin.terminal.PaintException;
import com.vaadin.terminal.PaintTarget;
import com.vaadin.ui.AbstractComponent;
import com.vaadin.ui.CustomComponent;
import com.vaadin.ui.CustomLayout;
import com.vaadin.ui.Panel;
import com.vaadin.ui.Table;
import com.vaadin.ui.themes.ValoTheme;

/**
 * Server side component for the Vsearch_result widget.
 */
//@com.vaadin.ui.ClientWidget(com.example.main_window.client.ui.Vsearch_result.class)
public class search_result extends CustomComponent {
            public search_result() {
                Panel p = new Panel();
                p.setSizeUndefined();
                Table table = new Table();
                table.setHeight(150.0f, Unit.PERCENTAGE);
                table.setWidth("100%");
                table.addStyleName(ValoTheme.TABLE_COMPACT);
                BeanItemContainer<Person> container = new BeanItemContainer<Person>(Person.class);

                table.setContainerDataSource(container);
                ArrayList<Person> arraylist = new ArrayList<Person>();
                arraylist.add(new Person("Tom", "Smith","Victor",0100000,"","cash"));
                arraylist.add(new Person("Moataz", "Nader"," ",0100000,"","Credit"));
                arraylist.add(new Person("Yousra", " ","Raed",0100000,"","cash"));
                for (Person o : arraylist) {
                    container.addBean(o);
                }
                //table.setVisibleColumns(new Object[] {"NAME", "COMPANY", "CONTACT","PAYMENT"});

                table.setPageLength(9);
                p.setSizeFull();
                p.setContent(table);
                
                this.setSizeUndefined();
                this.setCompositionRoot(p);
            }

}

