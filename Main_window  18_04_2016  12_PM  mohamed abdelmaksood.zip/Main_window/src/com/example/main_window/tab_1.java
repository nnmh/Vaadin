package com.example.main_window;

import java.util.ArrayList;
import java.util.Map;

import com.vaadin.data.Property.ValueChangeEvent;
import com.vaadin.data.Property.ValueChangeListener;
import com.vaadin.data.util.BeanItemContainer;
import com.vaadin.server.Sizeable.Unit;
import com.vaadin.terminal.PaintException;
import com.vaadin.terminal.PaintTarget;
import com.vaadin.ui.AbstractComponent;
import com.vaadin.ui.Button;
import com.vaadin.ui.CheckBox;
import com.vaadin.ui.CustomComponent;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.Panel;
import com.vaadin.ui.Table;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.Button.ClickEvent;
import com.vaadin.ui.themes.ValoTheme;

/**
 * Server side component for the Vtab_1 widget.
 */
//@com.vaadin.ui.ClientWidget(com.example.main_window.client.ui.Vtab_1.class)
public class tab_1 extends CustomComponent {
    BeanItemContainer<Credit_Entity> container = new BeanItemContainer<Credit_Entity>(Credit_Entity.class);
    tab1 top;
            public tab_1() {
                Panel p = new Panel();
                p.setSizeUndefined();
                top = new tab1();
               
                top.custodian_CheckBox.addValueChangeListener(new ValueChangeListener() {
                	@Override
                	public void valueChange(ValueChangeEvent event) { 
                		//top.custodianLayout=new VerticalLayout();
                		top.custodianLayout.setEnabled(!top.custodianLayout.isEnabled());
                		top.custodianLayout.setVisible(!top.custodianLayout.isVisible());
                		if(top.getHeight()>=600){
                			Integer curSize=(int) (top.getHeight()+300);
                			top.setHeight(curSize.toString()+"px");
                		}
                		else if(top.getHeight()>=800){
                			Integer curSize=(int) (top.getHeight()-300);
                			top.setHeight(curSize.toString()+"px");                		}
                	}
                	});


                Table table1=top.credit_Table;
                
                table1.addStyleName(ValoTheme.TABLE_COMPACT);
                
                table1.setContainerDataSource(container);
                ArrayList<Credit_Entity> arraylist = new ArrayList<Credit_Entity>();
                arraylist.add(new Credit_Entity("Tom", "Smith",0100000));
                arraylist.add(new Credit_Entity("Moataz", "Nader",0100000));
                arraylist.add(new Credit_Entity("Yousra","Raed",0100000));
                for (Credit_Entity o : arraylist) {
                    container.addBean(o);
                }
                table1.setEditable(true);                
                table1.addGeneratedColumn("Remove/Add",new Table.ColumnGenerator() {
                        public Object generateCell(
                            Table source,final Object itemId,Object
                            columnId){
                                HorizontalLayout hLayout = new HorizontalLayout();
                                Button removeButton = new Button("-");
                                removeButton.addClickListener(new Button.ClickListener(){
                                public void buttonClick(ClickEvent event) {
                                    table1.removeItem(itemId);
                                    }
                                });
                                Button addButton = new Button("+");
                                addButton.addClickListener(new Button.ClickListener(){
                                public void buttonClick(ClickEvent event) {
                                    container.addItem(new Credit_Entity(" "," ",0));
                                    }
                                });
                                hLayout.addComponent(removeButton);
                                hLayout.addComponent(addButton);
                                return hLayout;
                          
                                }
                        });
                p.setContent(top);
                p.setSizeFull();
                this.setSizeUndefined();
                this.setCompositionRoot(p);
            }
            public void setCreditTableVisible(Boolean Visible){
            	top.credit_Table.setVisible(Visible);
            	top.credit_Table.setEnabled(Visible);
            }
            public Boolean getCreditTableVisible(){
            	return top.credit_Table.isVisible();
            }
}