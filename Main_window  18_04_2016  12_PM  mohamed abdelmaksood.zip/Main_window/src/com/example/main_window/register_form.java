package com.example.main_window;

import java.util.Map;

import com.google.gwt.user.client.ui.ClickListener;
import com.google.gwt.user.client.ui.Widget;
import com.vaadin.data.Property.ValueChangeEvent;
import com.vaadin.data.Property.ValueChangeListener;
import com.vaadin.server.Sizeable.Unit;
import com.vaadin.terminal.PaintException;
import com.vaadin.terminal.PaintTarget;
import com.vaadin.ui.AbstractComponent;
import com.vaadin.ui.Button;
import com.vaadin.ui.ClientWidget;
import com.vaadin.ui.CustomComponent;
import com.vaadin.ui.Panel;
import com.vaadin.ui.TabSheet;
import com.vaadin.ui.TabSheet.Tab;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.Button.*;


/**
 * Server side component for the Vregister_form widget.
 */
//@com.vaadin.ui.ClientWidget(com.example.main_window.client.ui.Vregister_form.class)
public class register_form extends CustomComponent {
        public register_form() {
            Panel p = new Panel();
           //VerticalLayout vLayout = new VerticalLayout();
           registeration regForm = new registeration();          
            p.setSizeUndefined();
            p.setSizeFull();

        
            
            /*final VerticalLayout layout1 = new VerticalLayout(new tab_1() );
            layout1.setMargin(true);*/
            final tab_1 layout1 = new tab_1( );
            regForm.tabs.addTab(layout1,"Basics");
            final VerticalLayout layout2 = new VerticalLayout(new tab_2() );
            layout2.setMargin(true);
            regForm.tabs.addTab(layout2,"Contacts");
            final VerticalLayout layout3 = new VerticalLayout(new RTable() );
            layout3.setMargin(true);
            regForm.tabs.addTab(layout3,"Relations");
            final VerticalLayout layout4 = new VerticalLayout(new attachdoc() );
            layout4.setMargin(true);
            regForm.tabs.addTab(layout4,"Attached Documents");
            //one first = new one();
            
            regForm.saveButton.addClickListener(new Button.ClickListener(){
                public void buttonClick(ClickEvent event) {
             	   //startSaving();
                }
                });
            
            regForm.payment.addValueChangeListener(new ValueChangeListener() {
				
				@Override
				public void valueChange(ValueChangeEvent event) {
					// TODO Auto-generated method stub
					String value= event.getProperty().getValue().toString();
					if (value.equals("Credit")){
						layout1.setCreditTableVisible(true);
						
					}
					else
						layout1.setCreditTableVisible(false);
				}
			});
            p.setContent(regForm);
            p.setSizeFull();
            this.setSizeUndefined();
            this.setCompositionRoot(p);
        }
       /* private void startSaving(){
        	
        }*/
}