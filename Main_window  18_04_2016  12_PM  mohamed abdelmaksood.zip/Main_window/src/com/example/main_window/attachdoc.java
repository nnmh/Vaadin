package com.example.main_window;

import java.util.ArrayList;
import java.util.Map;

import com.vaadin.data.util.BeanItemContainer;
import com.vaadin.server.Sizeable.Unit;
import com.vaadin.terminal.PaintException;
import com.vaadin.terminal.PaintTarget;
import com.vaadin.ui.AbstractComponent;
import com.vaadin.ui.Button;
import com.vaadin.ui.CustomComponent;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.Panel;
import com.vaadin.ui.Table;
import com.vaadin.ui.Button.ClickEvent;
import com.vaadin.ui.themes.ValoTheme;

/**
 * Server side component for the Vattachdoc widget.
 */
//@com.vaadin.ui.ClientWidget(com.example.main_window.client.ui.Vattachdoc.class)
public class attachdoc extends CustomComponent {
        public attachdoc() {
            Panel p = new Panel();
            p.setSizeUndefined();
            Attach attach = new Attach();
            p.setContent(attach);
            p.setSizeFull();
            this.setSizeUndefined();
            this.setCompositionRoot(p);
            BeanItemContainer<Docs> container = new BeanItemContainer<Docs>(Docs.class);
            attach.table.setContainerDataSource(container);
            ArrayList<Docs> arraylist = new ArrayList<Docs>();
            arraylist.add(new Docs("Profile.jpeg", "Profile Picture","12/12/2006"));
            arraylist.add(new Docs("lab.pdf", "Lab Result","22/8/2007"));
           
            for (Docs o : arraylist) {
                container.addBean(o);
            }
            

            //table.setVisibleColumns(new Object[] {"NAME", "COMPANY", "CONTACT","PAYMENT"});

            attach.table.setPageLength(4);
            
            p.setSizeFull();
         
            
            attach.table.addGeneratedColumn("Remove/Add",new Table.ColumnGenerator() {
                    public Object generateCell(
                        Table source,final Object itemId,Object
                        columnId){
                            HorizontalLayout hLayout = new HorizontalLayout();
                            Button removeButton = new Button("-");
                            removeButton.addClickListener(new Button.ClickListener(){
                            public void buttonClick(ClickEvent event) {
                                attach.table.removeItem(itemId);
                                }
                            });
                            Button addButton = new Button("+");
                            addButton.addClickListener(new Button.ClickListener(){
                            public void buttonClick(ClickEvent event) {
                                container.addItem(new person2(" "," "," ",0));
                                }
                            });
                            hLayout.addComponent(removeButton);
                            hLayout.addComponent(addButton);
                            return hLayout;
                      
                            }
                    });
        }
        
}