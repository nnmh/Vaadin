package com.example.main_window;

import java.util.Map;

import com.vaadin.terminal.PaintException;
import com.vaadin.terminal.PaintTarget;
import com.vaadin.ui.AbstractComponent;
import com.vaadin.ui.CustomComponent;
import com.vaadin.ui.Panel;

/**
 * Server side component for the Vmain_panel widget.
 */
//@com.vaadin.ui.ClientWidget(com.example.main_window.client.ui.Vmain_panel.class)
public class main_panel extends CustomComponent {
    public main_panel() {
        Panel p = new Panel();
        p.setSizeUndefined();
        top top = new top();
        p.setContent(top);
        p.setSizeFull();
        this.setSizeUndefined();
        this.setCompositionRoot(p);
    }
}

