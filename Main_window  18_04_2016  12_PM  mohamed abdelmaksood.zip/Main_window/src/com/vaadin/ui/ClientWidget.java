package com.vaadin.ui;

public @interface ClientWidget {

}
