package com.example.main_window.client.top_panel;

import com.vaadin.shared.communication.ClientRpc;

public interface top_panelClientRpc extends ClientRpc {

	// TODO example API
	public void alert(String message);

}