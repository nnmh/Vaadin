package com.example.main_window.client.top_panel;

import com.google.gwt.user.client.ui.Label;

// TODO extend any GWT Widget
public class top_panelWidget extends Label {

	public static final String CLASSNAME = "top_panel";

	public top_panelWidget() {

		// setText("top_panel sets the text via top_panelConnector using top_panelState");
		setStyleName(CLASSNAME);

	}

}