package com.example.main_window.client.tree_menu;

import com.vaadin.shared.communication.ClientRpc;

public interface tree_menuClientRpc extends ClientRpc {

	// TODO example API
	public void alert(String message);

}