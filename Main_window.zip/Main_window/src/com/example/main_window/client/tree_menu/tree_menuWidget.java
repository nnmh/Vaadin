package com.example.main_window.client.tree_menu;

import com.google.gwt.user.client.ui.Label;

// TODO extend any GWT Widget
public class tree_menuWidget extends Label {

	public static final String CLASSNAME = "tree_menu";

	public tree_menuWidget() {

		// setText("tree_menu sets the text via tree_menuConnector using tree_menuState");
		setStyleName(CLASSNAME);

	}

}