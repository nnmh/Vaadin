package com.example.main_window;

import java.util.Map;


import com.vaadin.terminal.PaintException;
import com.vaadin.terminal.PaintTarget;
import com.vaadin.ui.AbstractComponent;
import com.vaadin.ui.Button;
import com.vaadin.ui.CustomComponent;
import com.vaadin.ui.Panel;
import com.vaadin.ui.Button.ClickEvent;

/**
 * Server side component for the Vsimple_search widget.
 */
//@com.vaadin.ui.ClientWidget(com.example.main_window.client.ui.Vsimple_search.class)
public class simple_search extends CustomComponent {
    public simple_search() {
        Panel p = new Panel();
        simple test = new simple();
        search_result r= new search_result();
        p.setSizeFull();
        p.setSizeUndefined();
         
            p.setContent(test);
            this.setSizeUndefined();
            this.setCompositionRoot(p);
            detailed detail = new detailed();
            
            test.detailed.addClickListener(new Button.ClickListener() {
                public void buttonClick(ClickEvent event) {
                    
                    p.setContent(detail);
            }
           });
            test.search.addClickListener(new Button.ClickListener() {
                public void buttonClick(ClickEvent event) {
                    
                 
            }
           });
            detail.simpled.addClickListener(new Button.ClickListener() {
                public void buttonClick(ClickEvent event) {
                    
                    p.setContent(test);
            }
           });
            detail.simpled.addClickListener(new Button.ClickListener() {
                public void buttonClick(ClickEvent event) {
                    
                    
            }
           });
    }

	

}

