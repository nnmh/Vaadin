package com.example.main_window;

public class Docs {
String filename;
String type;
String date;

public Docs() {
    // TODO Auto-generated constructor stub
}
public Docs(String file, String t,String d) {
    this.filename=file;
    this.type=t;
    this.date=d;
}
public String getFilename() {
    return filename;
}
public void setFilename(String filename) {
    this.filename = filename;
}
public String getType() {
    return type;
}
public void setType(String type) {
    this.type = type;
}
public String getDate() {
    return date;
}
public void setDate(String date) {
    this.date = date;
}



}
