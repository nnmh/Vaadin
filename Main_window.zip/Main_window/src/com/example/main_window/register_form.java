package com.example.main_window;

import java.util.Map;

import com.vaadin.server.Sizeable.Unit;
import com.vaadin.terminal.PaintException;
import com.vaadin.terminal.PaintTarget;
import com.vaadin.ui.AbstractComponent;
import com.vaadin.ui.ClientWidget;
import com.vaadin.ui.CustomComponent;
import com.vaadin.ui.Panel;
import com.vaadin.ui.TabSheet;
import com.vaadin.ui.TabSheet.Tab;
import com.vaadin.ui.VerticalLayout;


/**
 * Server side component for the Vregister_form widget.
 */
//@com.vaadin.ui.ClientWidget(com.example.main_window.client.ui.Vregister_form.class)
public class register_form extends CustomComponent {
        public register_form() {
            Panel p = new Panel();
           VerticalLayout vLayout = new VerticalLayout();
           registeration test = new registeration();

           
            p.setSizeUndefined();
            p.setSizeFull();

        
            
            final VerticalLayout layout1 = new VerticalLayout(new tab_1() );
            layout1.setMargin(true);
            test.tabs.addTab(layout1,"Basics");
            final VerticalLayout layout2 = new VerticalLayout(new tab_2() );
            layout2.setMargin(true);
            test.tabs.addTab(layout2,"Contacts");
            final VerticalLayout layout3 = new VerticalLayout(new RTable() );
            layout3.setMargin(true);
            test.tabs.addTab(layout3,"Relations");
            final VerticalLayout layout4 = new VerticalLayout(new attachdoc() );
            layout4.setMargin(true);
            test.tabs.addTab(layout4,"Attached Documents");
            //one first = new one();
            p.setContent(test);
            
            p.setSizeFull();
            this.setSizeUndefined();
            this.setCompositionRoot(p);
        }
        
}