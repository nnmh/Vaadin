package com.example.main_window;

public class Person {
    String First_Name;
    String Second_Name;
    String Third_Name;
    int Contact;
    String Company;
    String Payment_Type;
    
    public Person() {
    }
    
    public Person(String fname,String sname,String lname, int contact, String company, String payment_type){
            this.First_Name=fname;
            this.Second_Name=sname;
            this.Third_Name=lname;
            this.Contact= contact;
            this.Company= company;
            this.Payment_Type= payment_type;
            
    }

    public String getFirst_Name() {
        return First_Name;
    }

    public void setFirst_Name(String first_Name) {
        First_Name = first_Name;
    }

    public String getSecond_Name() {
        return Second_Name;
    }

    public void setSecond_Name(String second_Name) {
        Second_Name = second_Name;
    }

    public String getThird_Name() {
        return Third_Name;
    }

    public void setThird_Name(String third_Name) {
        Third_Name = third_Name;
    }


    public int getcontact() {
            return this.Contact;
    }

    public void setcontact(int contact) {
            this.Contact = contact;
    }

    public String getCompany() {
            return this.Company;
    }

    public void setCompany(String company) {
            this.Company = company;
    }
    public String getpayment() {
        return this.Payment_Type;
}
    
    public void setpayment(String payment) {
            this.Payment_Type = payment;
    }
}
