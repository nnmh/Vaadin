package com.example.main_window;

import java.awt.Label;
import java.util.ArrayList;
import java.util.Map;

import com.vaadin.data.util.BeanItemContainer;
import com.vaadin.server.Sizeable.Unit;
import com.vaadin.terminal.PaintException;
import com.vaadin.terminal.PaintTarget;
import com.vaadin.ui.AbstractComponent;
import com.vaadin.ui.Button;
import com.vaadin.ui.Component;
import com.vaadin.ui.CustomComponent;
import com.vaadin.ui.HorizontalLayout;
import com.vaadin.ui.Panel;
import com.vaadin.ui.Table;
import com.vaadin.ui.VerticalLayout;
import com.vaadin.ui.Button.ClickEvent;
import com.vaadin.ui.themes.ValoTheme;

/**
 * Server side component for the VRTable widget.
 */
//@com.vaadin.ui.ClientWidget(com.example.main_window.client.ui.VRTable.class)
public class RTable extends CustomComponent {
    BeanItemContainer<person2> container = new BeanItemContainer<person2>(person2.class);
    BeanItemContainer<company> container2 = new BeanItemContainer<company>(company.class);
            public RTable() {
                VerticalLayout vLayout = new VerticalLayout();
                Table table1 = new Table();
                Table table2 = new Table();

               
                vLayout.addComponent(table1);
                vLayout.addComponent(table2);
                Panel p = new Panel();
                p.setSizeUndefined();
                
                table1.setHeight(50.0f, Unit.PERCENTAGE);
                //table1.setWidth("100%");
                table1.addStyleName(ValoTheme.TABLE_COMPACT);
                
                table1.setContainerDataSource(container);
                ArrayList<person2> arraylist = new ArrayList<person2>();
                arraylist.add(new person2("Tom", "Smith","Victor",0100000));
                arraylist.add(new person2("Moataz", "Nader"," ",0100000));
                arraylist.add(new person2("Yousra", " ","Raed",0100000));
                for (person2 o : arraylist) {
                    container.addBean(o);
                }
                table1.setEditable(true);
                table2.setHeight(50.0f, Unit.PERCENTAGE);
                //table2.setWidth("100%");
                table2.addStyleName(ValoTheme.TABLE_COMPACT);
                
                table2.setContainerDataSource(container2);
                ArrayList<company> arraylist2 = new ArrayList<company>();
                arraylist2.add(new company("Smartera", "Insurance",0100000));
             
                for (company o : arraylist2) {
                    container2.addBean(o);
                }
                //table.setVisibleColumns(new Object[] {"NAME", "COMPANY", "CONTACT","PAYMENT"});

                table1.setPageLength(4);
                table2.setPageLength(4);
                p.setSizeFull();
                p.setContent(vLayout);
                
                table1.addGeneratedColumn("Remove/Add",new Table.ColumnGenerator() {
                        public Object generateCell(
                            Table source,final Object itemId,Object
                            columnId){
                                HorizontalLayout hLayout = new HorizontalLayout();
                                Button removeButton = new Button("-");
                                removeButton.addClickListener(new Button.ClickListener(){
                                public void buttonClick(ClickEvent event) {
                                    table1.removeItem(itemId);
                                    }
                                });
                                Button addButton = new Button("+");
                                addButton.addClickListener(new Button.ClickListener(){
                                public void buttonClick(ClickEvent event) {
                                    container.addItem(new person2(" "," "," ",0));
                                    }
                                });
                                hLayout.addComponent(removeButton);
                                hLayout.addComponent(addButton);
                                return hLayout;
                          
                                }
                        });
                table2.addGeneratedColumn("Remove/Add",new Table.ColumnGenerator() {
                    public Object generateCell(
                        Table source,final Object itemId,Object
                        columnId){
                            HorizontalLayout hLayout = new HorizontalLayout();
                            Button removeButton = new Button("-");
                            removeButton.addClickListener(new Button.ClickListener(){
                            public void buttonClick(ClickEvent event) {
                                table2.removeItem(itemId);
                                }
                            });
                            Button addButton = new Button("+");
                            addButton.addClickListener(new Button.ClickListener(){
                            public void buttonClick(ClickEvent event) {
                                container2.addItem(new company(" "," ", 0));
                                }
                            });
                            hLayout.addComponent(removeButton);
                            hLayout.addComponent(addButton);
                            return hLayout;
                      
                            }
                    });
                
                this.setSizeUndefined();
                this.setCompositionRoot(p);
           }
}